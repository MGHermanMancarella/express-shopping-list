const items = [];

module.exports = { items };